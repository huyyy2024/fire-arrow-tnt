package com.firebow.event;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Runtime singleton — quản lý queue placement, chạy client-side.
 *
 * Pattern học từ BOOST-FPS:
 *   Tick T   : arrow hit → tính railPos → enqueue
 *   Tick T+1 : onClientTick() → gửi packet đặt Rail
 *   Tick T+2 : grimSync delay → gửi packet spawn TNT Cart (drop + activate)
 *
 * Cách gửi packet giống người thật:
 *   1. Đổi slot tay về item Rail (tìm trong hotbar)
 *      hoặc dùng Creative inventory packet nếu creative mode
 *   2. Gửi PlayerInteractBlockC2SPacket → server nhận = player đặt block
 *   3. Đổi slot về TNT Minecart
 *   4. Gửi PlayerInteractBlockC2SPacket lần nữa → server spawn cart
 *
 * Nếu không có Rail/Cart trong hotbar:
 *   → Dùng ClientPlayerInteractionManager.interactBlock() trực tiếp
 *     (đây là cách Baritone, impact, v.v. làm)
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    // Mỗi pending entry cần 2 tick để xử lý (rail tick + cart tick)
    private final Queue<PendingPlacement> queue = new ConcurrentLinkedQueue<>();
    private static final int MAX_QUEUE = 3;

    // Tick counter để implement grimSync delay
    private int waitTick = 0;
    private PendingPlacement current = null;
    // 0=idle, 1=đặt rail (tick này), 2=đặt cart (tick sau)
    private int phase = 0;

    private FireBowRuntime() {}

    public void enqueue(BlockPos railPos) {
        if (queue.size() < MAX_QUEUE) {
            queue.add(new PendingPlacement(railPos));
        }
    }

    /**
     * Gọi từ ClientTickMixin mỗi client tick.
     *
     * grimSync: mỗi action cách nhau 1 tick → server thấy sequence
     * hợp lệ, không khác gì player thật đặt block rồi đặt cart.
     */
    public void onClientTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        // Đang xử lý current placement
        if (current != null) {
            if (phase == 1) {
                // Tick này: đặt Rail
                placeRail(client, current.railPos);
                phase = 2;
                return;
            }
            if (phase == 2) {
                // Tick sau (grimSync): đặt TNT Cart lên trên rail
                placeCart(client, current.railPos);
                current = null;
                phase   = 0;
                return;
            }
        }

        // Lấy pending tiếp theo nếu có
        if (!queue.isEmpty()) {
            current = queue.poll();
            phase   = 1;
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Đặt Rail — gửi PlayerInteractBlockC2SPacket
    // ─────────────────────────────────────────────────────────────
    private void placeRail(MinecraftClient client, BlockPos railPos) {
        ClientPlayerEntity      player = client.player;
        ClientPlayerInteractionManager im = client.interactionManager;
        if (im == null) return;

        // Tìm Rail trong hotbar, nếu không có thì bỏ qua
        int railSlot = findInHotbar(player, Items.RAIL);
        if (railSlot == -1) {
            // Fallback: thử POWERED_RAIL, DETECTOR_RAIL
            railSlot = findInHotbar(player, Items.POWERED_RAIL);
        }
        if (railSlot == -1) return;

        int prevSlot = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = railSlot;

        // Gửi packet đặt block giống người thật đặt bằng chuột phải
        BlockHitResult hitResult = new BlockHitResult(
            Vec3d.ofCenter(railPos),    // exact hit position
            Direction.UP,               // đặt lên mặt trên block bên dưới
            railPos.down(),             // block đang đặt lên (nền)
            false
        );

        im.interactBlock(player, Hand.MAIN_HAND, hitResult);

        // Khôi phục slot sau khi gửi packet — 1 tick sau để không bị flag
        player.getInventory().selectedSlot = prevSlot;
    }

    // ─────────────────────────────────────────────────────────────
    //  Đặt TNT Cart — gửi PlayerInteractBlockC2SPacket lần 2
    //  Server sẽ spawn TntMinecartEntity khi nhận packet này
    //  với item TNT_MINECART trong tay trên block RAIL
    // ─────────────────────────────────────────────────────────────
    private void placeCart(MinecraftClient client, BlockPos railPos) {
        ClientPlayerEntity      player = client.player;
        ClientPlayerInteractionManager im = client.interactionManager;
        if (im == null) return;

        // Phải có rail tại railPos (đặt tick trước) để cart spawn
        if (!client.world.getBlockState(railPos).isOf(Blocks.RAIL) &&
            !client.world.getBlockState(railPos).isOf(Blocks.POWERED_RAIL)) {
            return;
        }

        int cartSlot = findInHotbar(player, Items.TNT_MINECART);
        if (cartSlot == -1) return;

        int prevSlot = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = cartSlot;

        // Đặt cart lên trên rail — click vào mặt trên của rail block
        BlockHitResult hitResult = new BlockHitResult(
            Vec3d.ofCenter(railPos),
            Direction.UP,
            railPos,     // block đang interact = rail
            false
        );

        im.interactBlock(player, Hand.MAIN_HAND, hitResult);

        player.getInventory().selectedSlot = prevSlot;
    }

    // ─────────────────────────────────────────────────────────────
    //  Tìm item trong hotbar (slot 0-8)
    // ─────────────────────────────────────────────────────────────
    private int findInHotbar(ClientPlayerEntity player, net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.getItem() == item) return i;
        }
        return -1;
    }

    // ─────────────────────────────────────────────────────────────
    //  Data class
    // ─────────────────────────────────────────────────────────────
    private static class PendingPlacement {
        final BlockPos railPos;
        PendingPlacement(BlockPos p) { this.railPos = p; }
    }
}
